
AmobiLootDB = {
["stats"] = {
["nosource"] = 0,
["errors"] = 0,
["gathered"] = 0,
["hidden"] = 0,
["nolink"] = 0,
},
["others"] = {
},
["items"] = {
},
["kills"] = {
},
["version"] = 1,
["bosses"] = {
},
["client"] = {
["locale"] = "zhTW",
["version"] = "1.60.1",
["addon"] = "1.1.0",
["interface"] = 16001,
["build"] = "70790",
},
["loot"] = {
},
["settings"] = {
},
}
